import stdio
import sys

...

name1 = sys.argv[1] # First name
name2 = sys.argv[2] # Second name
name3 = sys.argv[3] # Third name
print("Hi " + name3 + ", " + name2 + ", and " + name1 + ".") # Concat and print