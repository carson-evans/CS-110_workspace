import stdio
import sys

...

name1 = sys.argv[1] # First name
name2 = sys.argv[2] # Second name
name3 = sys.argv[3] # Third name

stdio.write("Hi ")
stdio.write(name3)
stdio.write(", ")
stdio.write(name2)
stdio.write(", and ")
stdio.write(name1)
stdio.write(".")