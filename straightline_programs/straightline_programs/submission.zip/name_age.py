import stdio
import sys

...
# Get name and age from CLI
name = sys.argv[1]
age = sys.argv[2]

# Print result
print(name + " is " + age + " years old. ")